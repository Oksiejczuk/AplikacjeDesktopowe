﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace zDodatkowe1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Random r = new Random();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void opcja1_Checked(object sender, RoutedEventArgs e)
        {
            
        }

        private void zaznaczone(object sender, RoutedEventArgs e)
        {
            
        }

        private void zaznaczone1(object sender, RoutedEventArgs e)
        {
            kostka1.Visibility = Visibility.Visible;
            kostka2.Visibility = Visibility.Hidden;
            kostka3.Visibility = Visibility.Hidden;
            kostka4.Visibility = Visibility.Hidden;
            kostka5.Visibility = Visibility.Hidden;
            kostka6.Visibility = Visibility.Hidden;
        }

        private void zaznaczone6(object sender, RoutedEventArgs e)
        {
            kostka1.Visibility = Visibility.Visible;
            kostka2.Visibility = Visibility.Visible;
            kostka3.Visibility = Visibility.Visible;
            kostka4.Visibility = Visibility.Visible;
            kostka5.Visibility = Visibility.Visible;
            kostka6.Visibility = Visibility.Visible;
        }

        private void zaznaczone5(object sender, RoutedEventArgs e)
        {
            kostka1.Visibility = Visibility.Visible;
            kostka2.Visibility = Visibility.Visible;
            kostka3.Visibility = Visibility.Visible;
            kostka4.Visibility = Visibility.Visible;
            kostka5.Visibility = Visibility.Visible;
            kostka6.Visibility = Visibility.Hidden;
        }

        private void zaznacz(object sender, RoutedEventArgs e)
        {

        }

        private void zaznaczone4(object sender, RoutedEventArgs e)
        {
            kostka1.Visibility = Visibility.Visible;
            kostka2.Visibility = Visibility.Visible;
            kostka3.Visibility = Visibility.Visible;
            kostka4.Visibility = Visibility.Visible;
            kostka5.Visibility = Visibility.Hidden;
            kostka6.Visibility = Visibility.Hidden;
        }

        private void zaznaczone2(object sender, RoutedEventArgs e)
        {
            kostka1.Visibility = Visibility.Visible;
            kostka2.Visibility = Visibility.Visible;
            kostka3.Visibility = Visibility.Hidden;
            kostka4.Visibility = Visibility.Hidden;
            kostka5.Visibility = Visibility.Hidden;
            kostka6.Visibility = Visibility.Hidden;
        }

        private void zaznaczone3(object sender, RoutedEventArgs e)
        {
            kostka1.Visibility = Visibility.Visible;
            kostka2.Visibility = Visibility.Visible;
            kostka3.Visibility = Visibility.Visible;
            kostka4.Visibility = Visibility.Hidden;
            kostka5.Visibility = Visibility.Hidden;
            kostka6.Visibility = Visibility.Hidden;
        }

        private void rzucasz(object sender, RoutedEventArgs e)
        {
            if (opcja1.IsChecked == true)
            {
                int zmienna1 = 0;
                zmienna1 = r.Next(1,7);
                Wynik.Text = "Wynik : " + zmienna1;
            }
            if (opcja2.IsChecked == true)
            {
                int zmienna1 = 0; 
                int zmienna2 = 0;
                int suma = 0;
                zmienna1 = r.Next(1,7);
                zmienna2 = r.Next(1,7);
                suma = zmienna1 + zmienna2;

                Wynik.Text = "Wynik : " + suma;
            }
            if (opcja3.IsChecked == true)
            {
                int zmienna1 = 0;
                int zmienna2 = 0;
                int zmienna3 = 0;
                int suma = 0;
                zmienna1 = r.Next(1, 7);
                zmienna2 = r.Next(1, 7);
                zmienna3 = r.Next(1, 7);
                suma = zmienna1 + zmienna2 + zmienna3;

                Wynik.Text = "Wynik : " + suma;
            }
            if (opcja4.IsChecked == true)
            {
                int zmienna1 = 0;
                int zmienna2 = 0;
                int zmienna3 = 0;
                int zmienna4 = 0;
                int suma = 0;
                zmienna1 = r.Next(1, 7);
                zmienna2 = r.Next(1, 7);
                zmienna3 = r.Next(1, 7);
                zmienna4 = r.Next(1, 7);
                suma = zmienna1 + zmienna2 + zmienna3 + zmienna4;

                Wynik.Text = "Wynik : " + suma;
            }
            if (opcja5.IsChecked == true)
            {
                int zmienna1 = 0;
                int zmienna2 = 0;
                int zmienna3 = 0;
                int zmienna4 = 0;
                int zmienna5 = 0;
                int suma = 0;
                zmienna1 = r.Next(1, 7);
                zmienna2 = r.Next(1, 7);
                zmienna3 = r.Next(1, 7);
                zmienna4 = r.Next(1, 7);
                zmienna5 = r.Next(1, 7);
                suma = zmienna1 + zmienna2 + zmienna3 + zmienna4 + zmienna5;

                Wynik.Text = "Wynik : " + suma;
            }
            if (opcja6.IsChecked == true)
            {
                int zmienna1 = 0;
                int zmienna2 = 0;
                int zmienna3 = 0;
                int zmienna4 = 0;
                int zmienna5 = 0;
                int zmienna6 = 0;
                int suma = 0;
                zmienna1 = r.Next(1, 7);
                zmienna2 = r.Next(1, 7);
                zmienna3 = r.Next(1, 7);
                zmienna4 = r.Next(1, 7);
                zmienna5 = r.Next(1, 7);
                zmienna6 = r.Next(1, 7);
                suma = zmienna1 + zmienna2 + zmienna3 + zmienna4 + zmienna5 + zmienna6;

                Wynik.Text = "Wynik : " + suma;
            }
            else
            {
                Wynik.Text = "Nie wybrałeś żadnej opcji";
            }
            
                
        }
    }
}