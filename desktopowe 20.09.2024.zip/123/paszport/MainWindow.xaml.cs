﻿using System.Security.Policy;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace paszport
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void on_Click(object sender,RoutedEventArgs e )
        {
            string s_imie = "", s_nazwisko = "", s_kolor = "";
            s_imie = s_imie.Text;
            s_nazwisko = s_nazwisko.Text;
            if (niebieskie.IsChecked == true)
            {
                s_kolor = "niebieskie";
            }
            if (piwne.IsChecked == true)
            {
                s_kolor = "piwne";
            }
            if (zielone.IsChecked == true)
            {
                s_kolor = "zielone";
            }
            if(s_imie=="" || s_nazwisko = "") {
                MessageBox.Show("Uzupelnij dane");
            }
            else
            {
                MessageBox.Show(s_imie + " " + s_nazwisko + "kolor oczu" + s_kolor);
            }
        }
    private void zmiana_zdjecia(object sender, RoutedEventArgs e)
        {
            string num = numer.Text;
            MessageBox.Show(num);
            zdjecie.Source = new BitmapImage(new Uri("./" + numer + "-zdjecie.jpg", UriKind.Relative));
            odcisk.Source = new BitmapImage(new Uri("./" + numer + "-odcisk.jpg", UriKind.Relative));

        }


    }

}